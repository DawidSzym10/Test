﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace CzujnikCzadu.ModelDanych
{
    internal class CzujnikCzadu
    {
        private BateriaCzujnika bateria;
        public CzujnikCzadu(BateriaCzujnika bat, DateTime dt)
        {
            this.bateria = bat;
        }
        public string Komunikat()
        {
            if (bateria.SprawdzStanBaterii() > 85)
            {
                return "Wymień baterie";
            }
            else
            {
                return "Stan baterii Ok";
            }
        }
    }
}