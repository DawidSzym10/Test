﻿using CzujnikCzadu.ModelDanych;
internal class Program
{
    private static void Main(string[] args)
    {
        DateTime dt = new DateTime(2022, 10, 28);
        BateriaCzujnika oferta1 = new BateriaCzujnika("Duracell", 100, dt);
        Console.WriteLine(oferta1.Wypisz());
        
    }
}