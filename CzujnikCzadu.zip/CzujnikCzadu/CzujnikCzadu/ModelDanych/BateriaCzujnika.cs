﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace CzujnikCzadu.ModelDanych
{
    internal class BateriaCzujnika
    {
        private string NazwaProducenta;
        private int CzasDziałania;
        private DateTime DataZamontowaniaBaterii;
        public BateriaCzujnika(string nazwa, int czas, DateTime dt)
        {
            this.NazwaProducenta = nazwa;
            this.CzasDziałania = czas;
            this.DataZamontowaniaBaterii = dt;
        }
        public string nazwaProducenta { get { return NazwaProducenta; } }
        public int czasDziałania { get { return CzasDziałania; } }
        public DateTime dataZamontowaniaBaterii { get { return DataZamontowaniaBaterii; } }
        public int SprawdzStanBaterii()
        {
            DateTime teraz = DateTime.Now;
            int x = (teraz - dataZamontowaniaBaterii).Days;
            int zużycie = (x * 100) / CzasDziałania;
            return zużycie;
        }
        public string Wypisz()
        {
            string wynik ="Nazwa Producenta: " + NazwaProducenta + 
                "\nCzas działania beterii:" + CzasDziałania + 
                "\nData zamontowania baterii: " + DataZamontowaniaBaterii + 
                "\nZużycie baterii: " + SprawdzStanBaterii() + "%";
            return wynik;
        }
    }
}